Healthy lifestyle tracking app for BSU students!
Access site through: https://cobizuo.github.io/FitBSU/
