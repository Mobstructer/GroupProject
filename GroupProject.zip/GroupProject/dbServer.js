const express = require("express");
const app = express();
const mysql = require("mysql");
const ejs = require("ejs");

const PORT = 3000;

const db = mysql.createPool({
    connectionLimit: 100,
    host: "localhost",
    user: "newuser",
    database: "groupproject",
    port: "3306"
});

// Middleware to parse JSON requests
app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Set EJS as the view engine
app.set("view engine", "ejs");

// POST endpoint to handle form submission and insert data into the database
app.post('/submitData', (req, res) => {
    const {MunicipalityName, Population, AverageSalary, Area, CnID, StID} = req.body;
    const dataToInsert = {MunicipalityName, Population, AverageSalary, Area, CnID, StID};

    db.getConnection((err, connection) => {
        if (err) {
            console.error('Error getting connection:', err);
            res.status(500).json({ message: 'Error getting connection.' });
            return;
        }

        connection.query('INSERT INTO city SET ?', dataToInsert, (err, result) => {
            if (err) {
                console.error('Error inserting data:', err);
                res.status(500).json({ message: 'Error inserting data.'});
                return;
            }
            console.log('Inserted ' + result.affectedRows + ' row(s).');
            res.json({ message: 'Data inserted successfully.'});
            connection.release(); // Release the connection when done
        });
    });
});

// GET endpoint to render the view with data from MySQL
app.get('/view', (req, res) => {
    db.query('SELECT * FROM state', (err, data) => {
        if (err) {
            console.error('Error fetching data:', err);
            res.status(500).json({ message: 'Error fetching data.' });
            return;
        }
        res.render('view', { data });
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
